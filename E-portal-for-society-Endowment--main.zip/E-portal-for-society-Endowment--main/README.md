The E-prtal for society Endowment  is a web-based tool developed as part of a college project to help users easily find nearby old age homes. Built using HTML, CSS, JavaScript, and the Google Maps API, the application allows users to enter a location and view a map displaying nearby elderly care facilities. The tool aims to assist families, volunteers, and caregivers in locating suitable homes for the elderly with convenience and accuracy.

NOTE: ** MOST OF THE PAGES ARE DEVELOPED USING EMBEDDED CSS **
